'use client';

import React, { Suspense } from 'react';
import { CinematicExperience } from '@/components/cinematic/CinematicExperience';

export default function HomePage() {
  return (
    <Suspense
      fallback={
        <div
          style={{
            minHeight: '100vh',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            background: '#07090E',
            color: '#D4AF37',
            gap: 16,
          }}
        >
          <div
            style={{
              width: 48,
              height: 48,
              borderRadius: '50%',
              border: '2px solid rgba(212, 175, 55, 0.3)',
              borderTopColor: '#D4AF37',
              animation: 'spin 1s linear infinite',
            }}
          />
          <span style={{ fontSize: 12, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(245, 247, 251, 0.55)' }}>
            Awakening Celebrations Atelier...
          </span>
        </div>
      }
    >
      <CinematicExperience />
    </Suspense>
  );
}
