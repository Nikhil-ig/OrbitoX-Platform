'use client';

import React, { useMemo, useState } from 'react';
import Link from 'next/link';
import { ArrowRight, CalendarDays, Check, ChevronRight, Crown, Download, Eye, Gift, MapPin, MessageSquareText, Phone, Search, ShieldCheck, Sparkles, TrendingUp, Users } from 'lucide-react';
import { useEcosystem } from '../../lib/ecosystem-context';

const guests = [
  { name: 'Vikram Malhotra', status: 'Confirmed', party: '2 guests', tag: 'VIP' },
  { name: 'Pooja Bhatt', status: 'Confirmed', party: '1 guest', tag: 'Family' },
  { name: 'Devraj Singh', status: 'Declined', party: '0 guests', tag: 'Not attending' },
  { name: 'Ananya & Kabir', status: 'Pending', party: '2 guests', tag: 'Awaiting' },
];

const timeline = [
  { label: 'Guest list closes', date: '12 Feb', tint: '#f5e5bf' },
  { label: 'Final seating', date: '18 Feb', tint: '#8fd6b2' },
  { label: 'Live reveal', date: '20 Feb', tint: '#d8b36a' },
];

const metrics = [
  { label: 'RSVPs', value: '319 / 420', detail: '+18 this week' },
  { label: 'Shagun', value: '₹1,48,000', detail: 'Top performer' },
  { label: 'Share rate', value: '72%', detail: '+11% up' },
  { label: 'Guestbook', value: '184', detail: 'New notes' },
];

export default function DashboardPage() {
  const { currentRole, hostCelebration } = useEcosystem();
  const [search, setSearch] = useState('');

  const filteredGuests = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return guests;
    return guests.filter((guest) => guest.name.toLowerCase().includes(q) || guest.status.toLowerCase().includes(q));
  }, [search]);

  return (
    <main
      style={{
        minHeight: '100vh',
        background: 'radial-gradient(circle at top, rgba(216,179,106,0.12), transparent 18%), linear-gradient(180deg, #0a0d12 0%, #0d1118 100%)',
        color: '#f4f7fb',
      }}
    >
      <div className="container" style={{ padding: '28px 0 64px' }}>
        <header
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: 18,
            marginBottom: 24,
            flexWrap: 'wrap',
          }}
        >
          <div>
            <div style={{ fontSize: 12, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(245,247,251,0.52)' }}>
              Dashboard
            </div>
            <h1 style={{ marginTop: 8, fontSize: 'clamp(2.2rem, 3vw, 3.2rem)', letterSpacing: '-0.07em' }}>Celebration command center</h1>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
            <button type="button" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '10px 14px', borderRadius: 999, background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.08)', color: '#f4f7fb' }}>
              <ShieldCheck size={15} color="#f5e5bf" /> {currentRole}
            </button>
            <Link href="/create" className="btn-primary" style={{ padding: '12px 18px', fontWeight: 800 }}>
              New experience <ArrowRight size={16} />
            </Link>
          </div>
        </header>

        <section style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 16, marginBottom: 22 }}>
          {metrics.map((metric) => (
            <div key={metric.label} className="surface-panel" style={{ padding: 18 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
                <div style={{ fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(245,247,251,0.58)' }}>{metric.label}</div>
                <TrendingUp size={15} color="#f5e5bf" />
              </div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, letterSpacing: '-0.06em' }}>{metric.value}</div>
              <div style={{ marginTop: 8, color: 'rgba(245,247,251,0.62)' }}>{metric.detail}</div>
            </div>
          ))}
        </section>

        <section style={{ display: 'grid', gridTemplateColumns: '1.3fr 0.7fr', gap: 18, marginBottom: 18 }}>
          <div className="surface-panel" style={{ padding: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18, gap: 12, flexWrap: 'wrap' }}>
              <div>
                <div style={{ fontSize: 12, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(245,247,251,0.52)' }}>Current experience</div>
                <h2 style={{ marginTop: 6, fontSize: 'clamp(1.7rem, 2vw, 2.5rem)', letterSpacing: '-0.06em' }}>{hostCelebration?.coupleTitle || 'Aarav & Meera'}</h2>
              </div>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '8px 12px', borderRadius: 999, background: 'rgba(143,214,178,0.12)', border: '1px solid rgba(143,214,178,0.26)', color: '#9be8c2', fontSize: 11, fontWeight: 800, letterSpacing: '0.12em', textTransform: 'uppercase' }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#8fd6b2', display: 'inline-block' }} /> live
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: 16 }}>
              <div style={{ borderRadius: 20, overflow: 'hidden', minHeight: 220, background: 'linear-gradient(135deg, rgba(216,179,106,0.28), rgba(15,18,26,0.8)), url(https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1200&q=80)', backgroundSize: 'cover', backgroundPosition: 'center', position: 'relative' }}>
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent, rgba(8,11,17,0.7))' }} />
                <div style={{ position: 'absolute', left: 18, right: 18, bottom: 18, display: 'flex', justifyContent: 'space-between', alignItems: 'end', gap: 14 }}>
                  <div>
                    <div style={{ fontSize: 12, letterSpacing: '0.16em', textTransform: 'uppercase', color: 'rgba(245,247,251,0.72)' }}>Venue</div>
                    <div style={{ marginTop: 6, fontWeight: 800, fontSize: '1.4rem' }}>Lake Palace, Udaipur</div>
                  </div>
                  <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '8px 10px', borderRadius: 999, background: 'rgba(8,11,17,0.45)', border: '1px solid rgba(255,255,255,0.12)' }}>
                    <CalendarDays size={14} /> 18 Feb 2027
                  </div>
                </div>
              </div>

              <div style={{ display: 'grid', gap: 12 }}>
                <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 16, padding: 14 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, marginBottom: 10 }}>
                    <div style={{ fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(245,247,251,0.56)' }}>Timeline</div>
                    <Crown size={14} color="#f5e5bf" />
                  </div>
                  <div style={{ display: 'grid', gap: 12 }}>
                    {timeline.map((item) => (
                      <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <span style={{ width: 10, height: 10, borderRadius: '50%', background: item.tint, display: 'inline-block' }} />
                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: 700 }}>{item.label}</div>
                          <div style={{ fontSize: 12, color: 'rgba(245,247,251,0.64)' }}>{item.date}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 16, padding: 14 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <div style={{ fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(245,247,251,0.56)' }}>Plan</div>
                    <div style={{ color: '#f5e5bf', fontWeight: 700 }}>Royal pass</div>
                  </div>
                  <div style={{ fontSize: '1.9rem', fontWeight: 800, letterSpacing: '-0.06em' }}>₹3,999</div>
                  <div style={{ marginTop: 6, color: 'rgba(245,247,251,0.62)' }}>Hosting + custom domain + guest portal</div>
                </div>
              </div>
            </div>
          </div>

          <aside className="surface-panel" style={{ padding: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, marginBottom: 18 }}>
              <div>
                <div style={{ fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(245,247,251,0.52)' }}>AI concierge</div>
                <div style={{ marginTop: 6, fontWeight: 800, fontSize: '1.2rem' }}>Guest flow</div>
              </div>
              <Sparkles size={18} color="#f5e5bf" />
            </div>

            <div style={{ display: 'grid', gap: 12 }}>
              {[
                { icon: MessageSquareText, title: 'Draft thank-you note', subtitle: 'Personalized for 4 family groups' },
                { icon: Gift, title: 'Shagun summary', subtitle: '₹1.48L collected so far' },
                { icon: Phone, title: 'WhatsApp recap', subtitle: '3 reminders queued' },
              ].map(({ icon: Icon, title, subtitle }) => (
                <div key={title} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 12px', borderRadius: 14, background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <div style={{ width: 36, height: 36, borderRadius: 12, background: 'rgba(216,179,106,0.12)', border: '1px solid rgba(216,179,106,0.26)', display: 'grid', placeItems: 'center' }}>
                    <Icon size={16} color="#f5e5bf" />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700 }}>{title}</div>
                    <div style={{ fontSize: 12, color: 'rgba(245,247,251,0.62)' }}>{subtitle}</div>
                  </div>
                  <ChevronRight size={16} color="rgba(245,247,251,0.7)" />
                </div>
              ))}
            </div>
          </aside>
        </section>

        <section style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
          <div className="surface-panel" style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
              <div>
                <div style={{ fontSize: 12, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(245,247,251,0.52)' }}>Guest list</div>
                <h3 style={{ marginTop: 6, fontSize: '1.5rem', letterSpacing: '-0.05em' }}>Who’s coming</h3>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 999, padding: '8px 12px' }}>
                <Search size={14} color="#f5e5bf" />
                <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search guest" style={{ background: 'transparent', border: 0, outline: 'none', color: '#f4f7fb', width: 120 }} />
              </div>
            </div>

            <div style={{ display: 'grid', gap: 10 }}>
              {filteredGuests.map((guest) => (
                <div key={guest.name} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, padding: '12px 14px', borderRadius: 14, border: '1px solid rgba(255,255,255,0.08)', background: 'rgba(255,255,255,0.02)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'linear-gradient(135deg, rgba(216,179,106,0.25), rgba(255,255,255,0.06))', display: 'grid', placeItems: 'center', fontWeight: 800 }}>{guest.name.split(' ').map((s) => s[0]).slice(0,2).join('')}</div>
                    <div>
                      <div style={{ fontWeight: 700 }}>{guest.name}</div>
                      <div style={{ color: 'rgba(245,247,251,0.62)', fontSize: 12 }}>{guest.party}</div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ padding: '6px 10px', borderRadius: 999, border: guest.status === 'Confirmed' ? '1px solid rgba(143,214,178,0.24)' : guest.status === 'Declined' ? '1px solid rgba(255,255,255,0.12)' : '1px solid rgba(216,179,106,0.2)', background: guest.status === 'Confirmed' ? 'rgba(143,214,178,0.12)' : 'rgba(255,255,255,0.02)', color: guest.status === 'Confirmed' ? '#9be8c2' : '#f5e5bf', fontSize: 11, fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase' }}>{guest.status}</span>
                    {guest.tag && <span style={{ color: 'rgba(245,247,251,0.62)', fontSize: 11, fontWeight: 700 }}>{guest.tag}</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="surface-panel" style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
              <div>
                <div style={{ fontSize: 12, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(245,247,251,0.52)' }}>Operations</div>
                <h3 style={{ marginTop: 6, fontSize: '1.5rem', letterSpacing: '-0.05em' }}>Quick actions</h3>
              </div>
            </div>

            <div style={{ display: 'grid', gap: 12 }}>
              {[
                { label: 'Send RSVP reminder', icon: Users },
                { label: 'Export seating plan', icon: Download },
                { label: 'Publish event page', icon: Eye },
                { label: 'Update venue notes', icon: MapPin },
              ].map(({ label, icon: Icon }) => (
                <button key={label} type="button" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, padding: '14px 14px', borderRadius: 14, background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.08)', color: '#f4f7fb', cursor: 'pointer' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{ width: 36, height: 36, borderRadius: 12, background: 'rgba(216,179,106,0.12)', border: '1px solid rgba(216,179,106,0.28)', display: 'grid', placeItems: 'center' }}>
                      <Icon size={16} color="#f5e5bf" />
                    </div>
                    <span style={{ fontWeight: 700 }}>{label}</span>
                  </div>
                  <ChevronRight size={16} color="rgba(245,247,251,0.7)" />
                </button>
              ))}
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
