'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Sparkles } from 'lucide-react';
import { useEcosystem } from '../../lib/ecosystem-context';

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { currentRole } = useEcosystem();

  const isDedicatedStudioOrExperience = pathname?.startsWith('/e/') || pathname?.startsWith('/create');

  if (isDedicatedStudioOrExperience) {
    return <>{children}</>;
  }

  const navItems = [
    { label: 'Collections', href: '/explore', active: pathname === '/explore' },
    { label: 'Themes', href: '/themes', active: pathname === '/themes' },
    { label: 'Plans', href: '/pricing', active: pathname === '/pricing' },
    { label: 'Workspace', href: '/dashboard', active: pathname?.startsWith('/dashboard') },
  ];

  return (
    <>
      <header
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 50,
          backdropFilter: 'blur(22px)',
          WebkitBackdropFilter: 'blur(22px)',
          background: 'rgba(10, 12, 16, 0.6)',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
        }}
      >
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', minHeight: '78px', gap: 18 }}>
          <Link href="/" style={{ display: 'inline-flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 36, height: 36, borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #f7e6c4 0%, #d7b36a 48%, #a97b32 100%)', boxShadow: '0 12px 30px rgba(216,179,106,0.25)' }}>
              <Sparkles size={16} color="#10151c" />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.05 }}>
              <span style={{ fontSize: '0.92rem', fontWeight: 800, letterSpacing: '-0.04em' }}>OrbitoX</span>
              <span style={{ fontSize: '0.56rem', letterSpacing: '0.18em', textTransform: 'uppercase', color: 'rgba(245,247,251,0.55)' }}>Celebrations</span>
            </div>
          </Link>

          <nav style={{ display: 'flex', alignItems: 'center', gap: 12, color: 'rgba(245,247,251,0.72)', fontSize: '0.84rem', fontWeight: 700 }}>
            {navItems.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                style={{
                  padding: '9px 14px',
                  borderRadius: 999,
                  background: item.active ? 'rgba(217,179,109,0.1)' : 'transparent',
                  border: item.active ? '1px solid rgba(217,179,109,0.28)' : '1px solid transparent',
                  color: item.active ? '#f5e4ba' : 'rgba(245,247,251,0.7)',
                }}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '8px 12px', borderRadius: 999, border: '1px solid rgba(255,255,255,0.08)', background: 'rgba(255,255,255,0.02)', color: '#f5e4ba', fontSize: 10, letterSpacing: '0.12em', fontWeight: 800, textTransform: 'uppercase' }}>
              {currentRole}
            </div>
            <Link href="/create" className="btn-primary" style={{ padding: '10px 18px', fontSize: '0.8rem', fontWeight: 800 }}>
              New event
            </Link>
          </div>
        </div>
      </header>

      {children}
    </>
  );
}
