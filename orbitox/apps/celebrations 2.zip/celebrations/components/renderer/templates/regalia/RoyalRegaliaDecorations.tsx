'use client';

import React from 'react';

/**
 * Intricate Mughal / Rajasthani Royal Archway (Jharokha Motif)
 */
export function RoyalArchwaySvg({ size = 48, color = '#D4AF37' }: { size?: number; color?: string }) {
  return (
    <svg
      width={size}
      height={size * 0.7}
      viewBox="0 0 100 70"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ display: 'inline-block' }}
    >
      <path
        d="M10 65 V 35 Q 10 15 50 5 Q 90 15 90 35 V 65"
        stroke={color}
        strokeWidth="1.8"
        fill="none"
      />
      <path
        d="M18 65 V 36 Q 18 20 50 12 Q 82 20 82 36 V 65"
        stroke={color}
        strokeWidth="1"
        strokeDasharray="2 2"
        fill="none"
      />
      {/* Central Ornamental Keystones */}
      <circle cx="50" cy="5" r="3" fill={color} />
      <circle cx="50" cy="12" r="2" fill={color} />
      {/* Decorative Finials */}
      <path d="M50 0 L 52 4 L 50 5 L 48 4 Z" fill={color} />
    </svg>
  );
}

/**
 * Imperial Wax-Seal Medallion with Gold-Embossed Crest
 */
export function RoyalWaxSeal({
  size = 64,
  sealColor = '#991B1B',
  crestColor = '#FFDF73',
  initials = 'OM',
}: {
  size?: number;
  sealColor?: string;
  crestColor?: string;
  initials?: string;
}) {
  return (
    <div
      style={{
        width: `${size}px`,
        height: `${size}px`,
        position: 'relative',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{
          filter: 'drop-shadow(0 6px 16px rgba(0, 0, 0, 0.45))',
        }}
      >
        {/* Organic scalloped wax edge */}
        <path
          d="M50 5 C62 5, 68 12, 78 15 C88 18, 93 28, 95 38 C97 48, 92 58, 89 68 C86 78, 77 86, 68 90 C59 94, 49 96, 39 93 C29 90, 20 84, 15 75 C10 66, 6 56, 7 46 C8 36, 14 26, 22 19 C30 12, 38 5, 50 5 Z"
          fill={sealColor}
        />
        {/* Embossed inner circle */}
        <circle cx="50" cy="50" r="34" stroke={crestColor} strokeWidth="1.5" strokeDasharray="3 2" fill="none" opacity="0.8" />
        <circle cx="50" cy="50" r="30" stroke={crestColor} strokeWidth="2" fill="none" opacity="0.9" />
        {/* Crown & Royal Flourish */}
        <path
          d="M38 40 L 42 34 L 50 38 L 58 34 L 62 40 Z"
          fill={crestColor}
        />
        <text
          x="50"
          y="62"
          fill={crestColor}
          fontSize="18"
          fontWeight="700"
          fontFamily="'Cinzel', 'Playfair Display', serif"
          textAnchor="middle"
          letterSpacing="2"
        >
          {initials}
        </text>
      </svg>
    </div>
  );
}

/**
 * Royal Gold Filigree Horizontal Divider with Central Diamond
 */
export function RoyalFiligreeDivider({ color = '#D4AF37', maxWidth = 480 }: { color?: string; maxWidth?: number }) {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '12px',
        maxWidth: `${maxWidth}px`,
        margin: '32px auto',
        width: '90%',
      }}
    >
      <div
        style={{
          flex: 1,
          height: '1px',
          background: `linear-gradient(90deg, transparent, ${color} 70%, ${color})`,
          opacity: 0.6,
        }}
      />
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          color: color,
        }}
      >
        <span style={{ fontSize: '10px', opacity: 0.8 }}>♦</span>
        <div
          style={{
            width: '8px',
            height: '8px',
            transform: 'rotate(45deg)',
            border: `1.5px solid ${color}`,
            backgroundColor: `${color}33`,
            boxShadow: `0 0 10px ${color}88`,
          }}
        />
        <span style={{ fontSize: '10px', opacity: 0.8 }}>♦</span>
      </div>
      <div
        style={{
          flex: 1,
          height: '1px',
          background: `linear-gradient(90deg, ${color}, ${color} 30%, transparent)`,
          opacity: 0.6,
        }}
      />
    </div>
  );
}
