'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Experience, Theme } from '@orbitox-io/celebrations';
import {
  Heart,
  Calendar,
  Clock,
  MapPin,
  Mail,
  Send,
  Volume2,
  VolumeX,
  CheckCircle2,
  Crown,
  Sparkles,
  Users,
  ArrowRight,
  Gift,
  Check,
} from 'lucide-react';
import { CosmicGoldCanvas } from './CosmicGoldCanvas';
import {
  RoyalArchwaySvg,
  RoyalWaxSeal,
  RoyalFiligreeDivider,
} from './RoyalRegaliaDecorations';
import { CoupleTitle } from '../../CoupleTitle';
import { WishesGuestbookSection } from '../../sections/WishesGuestbookSection';

interface Props {
  experience: Experience;
  theme: Theme;
}

export function RoyalRegaliaExperience({ experience, theme }: Props) {
  // RSVP Form State
  const [guestName, setGuestName] = useState('');
  const [guestContact, setGuestContact] = useState('');
  const [attendingStatus, setAttendingStatus] = useState<'ATTENDING' | 'DECLINED'>('ATTENDING');
  const [partySize, setPartySize] = useState(2);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [rsvpSubmitted, setRsvpSubmitted] = useState(false);

  // Audio State & Reference
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Digital Shagun Selected Amount
  const [selectedShagun, setSelectedShagun] = useState<number>(2100);
  const [shagunSent, setShagunSent] = useState(false);

  // Dynamic Data Extraction from Experience Payload
  const heroSection = experience.sections?.find((s) => s.sectionType === 'hero');
  const heroConfig = heroSection?.config || {};
  const coupleNames =
    (heroConfig.hostNames as string) ||
    experience.title ||
    'Aarav & Meera';
  const partnerNamesList = coupleNames.includes('&')
    ? coupleNames.split('&').map((s) => s.trim())
    : coupleNames.split(' and ').map((s) => s.trim());
  const partner1 = partnerNamesList[0] || 'Aarav';
  const partner2 = partnerNamesList[1] || 'Meera';
  const eventDateStr = (heroConfig.eventDate as string) || experience.eventDate || 'December 18, 2026';
  const venueLocation = (heroConfig.venueCity as string) || (heroConfig.venueName as string) || 'Udaipur, Rajasthan';

  // Couple Profile Section Data
  const coupleSection = experience.sections?.find((s) => s.sectionType === 'couple_profile');
  const coupleConfig = coupleSection?.config || {};
  const p1Name = (coupleConfig.partner1Name as string) || partner1;
  const p1Role = (coupleConfig.partner1Role as string) || 'The Groom';
  const p1Bio = (coupleConfig.partner1Bio as string) || '';
  const p1Image = (coupleConfig.partner1Image as string) || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=85';

  const p2Name = (coupleConfig.partner2Name as string) || partner2;
  const p2Role = (coupleConfig.partner2Role as string) || 'The Bride';
  const p2Bio = (coupleConfig.partner2Bio as string) || '';
  const p2Image = (coupleConfig.partner2Image as string) || 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600&q=85';

  // Venue & Maps Data
  const venueSection = experience.sections?.find((s) => s.sectionType === 'venue_map');
  const venueConfig = venueSection?.config || {};
  const venueNameStr = (venueConfig.venueName as string) || (heroConfig.venueName as string) || 'Jagmandir Island Palace';
  const venueAddressStr = (venueConfig.address as string) || '';
  const venueLocationStr = (venueConfig.venueCity as string) || venueLocation;
  const venueFullAddress = venueAddressStr
    ? venueAddressStr.toLowerCase().includes(venueNameStr.toLowerCase())
      ? venueAddressStr
      : `${venueNameStr}, ${venueAddressStr}`
    : `${venueNameStr}, ${venueLocationStr}`;

  // Itinerary Events Data
  const eventsSection = experience.sections?.find((s) => s.sectionType === 'events_schedule');
  const eventsConfig = eventsSection?.config || {};
  const eventsList = (eventsConfig.events as Array<{
    id: string;
    name: string;
    date: string;
    time: string;
    venue: string;
    dressCode: string;
    description: string;
  }>) || [
      {
        id: 'ev_1',
        name: 'Mehendi & Sangeet Soirée',
        date: eventDateStr,
        time: '04:00 PM onwards',
        venue: venueNameStr,
        dressCode: 'Royal Pastel & Traditional Chic',
        description: 'Henna artistry, celebratory folk melodies, and dinner under the stars.',
      },
      {
        id: 'ev_2',
        name: 'The Sacred Vows & Pheras',
        date: eventDateStr,
        time: '06:30 PM',
        venue: venueNameStr,
        dressCode: 'Regal Formal Indian',
        description: 'Sunset Vedic wedding ceremony under the royal floral mandap.',
      },
      {
        id: 'ev_3',
        name: 'Imperial Gala Banquet & Reception',
        date: eventDateStr,
        time: '08:30 PM',
        venue: venueNameStr,
        dressCode: 'Black Tie & Royal Elegance',
        description: 'Fine dining feast, royal toasts, and musical celebration.',
      },
    ];

  // RSVP Form Configuration
  const rsvpSection = experience.sections?.find((s) => s.sectionType === 'rsvp');
  const rsvpConfig = rsvpSection?.config || {};
  const allowPlusOneGuest = (rsvpConfig.askPlusOne as boolean) ?? true;

  const wishesSection = experience.sections?.find((s) => s.sectionType === 'wishes_guestbook') || {
    id: 'sec_wishes_guestbook',
    sectionType: 'wishes_guestbook' as const,
    title: 'Imperial Wishes & Blessings',
    order: 9,
    isEnabled: true,
    config: {
      title: 'Imperial Wishes & Blessings',
      subtitle: `Bestow your love and divine blessings upon ${p1Name} & ${p2Name}`,
      hostNames: coupleNames,
      venueCity: venueLocation,
    },
  };

  const toggleMusic = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().catch((e) => console.log('Audio autoplay prevented:', e));
      setIsPlaying(true);
    }
  };

  const handleRsvpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) return;

    setIsSubmitting(true);
    try {
      await fetch('/api/rsvp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          experienceId: experience.id,
          tenantId: experience.tenantId,
          guestName: guestName.trim(),
          contact: guestContact.trim(),
          status: attendingStatus,
          partySize,
        }),
      });
      setRsvpSubmitted(true);
    } catch (err) {
      console.warn('RSVP submission note:', err);
      setRsvpSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Extract initials for wax seal
  const initial1 = p1Name.charAt(0) || 'A';
  const initial2 = p2Name.charAt(0) || 'M';
  const crestInitials = `${initial1}${initial2}`;

  return (
    <div
      style={{
        backgroundColor: '#060814',
        color: '#FAF5EE',
        minHeight: '100vh',
        fontFamily: "'Cormorant Garamond', 'Cinzel', serif",
        position: 'relative',
        overflowX: 'hidden',
      }}
    >
      {/* Background Audio */}
      <audio
        ref={audioRef}
        loop
        preload="none"
        src="https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3"
      />

      {/* Living Stardust Cosmic Canvas */}
      <CosmicGoldCanvas />

      {/* Ambient Floating Palace Music Toggle */}
      <button
        onClick={toggleMusic}
        style={{
          position: 'fixed',
          top: '20px',
          right: '20px',
          zIndex: 90,
          backgroundColor: 'rgba(6, 8, 20, 0.75)',
          backdropFilter: 'blur(16px)',
          border: '1px solid rgba(212, 175, 55, 0.4)',
          borderRadius: '50%',
          width: '46px',
          height: '46px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#FFDF73',
          cursor: 'pointer',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.6), 0 0 15px rgba(212, 175, 55, 0.25)',
          transition: 'all 0.3s ease',
        }}
        title={isPlaying ? 'Mute Palace Melody' : 'Play Palace Melody'}
      >
        {isPlaying ? <Volume2 size={20} /> : <VolumeX size={20} />}
      </button>

      {/* ─── HERO SECTION: GRAND PALACE ARCH ─── */}
      <section
        style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          padding: '80px 20px',
          position: 'relative',
          zIndex: 10,
        }}
      >
        <div style={{ maxWidth: '820px', margin: '0 auto' }}>
          {/* Ornamental Arch Motif */}
          <div style={{ marginBottom: '16px' }}>
            <RoyalArchwaySvg size={64} color="#D4AF37" />
          </div>

          <span
            style={{
              display: 'inline-block',
              fontFamily: "'Plus Jakarta Sans', sans-serif",
              fontSize: '0.78rem',
              letterSpacing: '3px',
              textTransform: 'uppercase',
              color: '#FFDF73',
              marginBottom: '14px',
              padding: '6px 18px',
              borderRadius: '9999px',
              backgroundColor: 'rgba(212, 175, 55, 0.12)',
              border: '1px solid rgba(212, 175, 55, 0.3)',
            }}
          >
            Auspicious Imperial Union
          </span>

          <p
            style={{
              fontSize: 'clamp(1rem, 2.5vw, 1.25rem)',
              color: 'rgba(250, 245, 238, 0.8)',
              fontStyle: 'italic',
              margin: '0 auto 18px auto',
              maxWidth: '520px',
              lineHeight: 1.6,
            }}
          >
            With the divine grace of the Almighty and blessings of our elders
          </p>

          {/* Monumental Royal Couple Names */}
          <CoupleTitle
            as="h1"
            title={coupleNames}
            flourishColor="#D4AF37"
            style={{
              fontFamily: "'Cinzel', 'Playfair Display', serif",
              fontSize: 'clamp(2.5rem, 8vw, 4.8rem)',
              fontWeight: 700,
              letterSpacing: '2px',
              lineHeight: 1.12,
              margin: '0 0 16px 0',
              background: 'linear-gradient(135deg, #FFFFFF 20%, #FFDF73 50%, #D4AF37 80%, #B38728 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              filter: 'drop-shadow(0 4px 20px rgba(212, 175, 55, 0.35))',
            }}
          />

          <p
            style={{
              fontSize: 'clamp(1.05rem, 3vw, 1.35rem)',
              letterSpacing: '1.5px',
              color: '#E5E7EB',
              marginBottom: '32px',
              textTransform: 'uppercase',
              fontWeight: 400,
            }}
          >
            Cordially request the honor of your presence to celebrate their wedding
          </p>

          <RoyalFiligreeDivider color="#D4AF37" maxWidth={360} />

          {/* Date & Palace Badge */}
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '16px',
              padding: '14px 28px',
              borderRadius: '16px',
              backgroundColor: 'rgba(212, 175, 55, 0.08)',
              border: '1px solid rgba(212, 175, 55, 0.35)',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.4)',
              backdropFilter: 'blur(12px)',
              marginBottom: '36px',
              flexWrap: 'wrap',
              justifyContent: 'center',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#FFDF73' }}>
              <Calendar size={18} />
              <span style={{ fontSize: '1.05rem', fontWeight: 600 }}>{eventDateStr}</span>
            </div>
            <span style={{ color: 'rgba(212, 175, 55, 0.4)' }}>•</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#FAF5EE' }}>
              <MapPin size={18} color="#D4AF37" />
              <span style={{ fontSize: '1.05rem' }}>{venueLocation}</span>
            </div>
          </div>

          <br />

          {/* Primary CTA Button */}
          <button
            onClick={() => scrollTo('regalia-rsvp')}
            style={{
              padding: '16px 42px',
              borderRadius: '9999px',
              background: 'linear-gradient(135deg, #FFDF73 0%, #D4AF37 50%, #B38728 100%)',
              color: '#060814',
              fontWeight: 700,
              fontSize: '1rem',
              letterSpacing: '2px',
              textTransform: 'uppercase',
              fontFamily: "'Plus Jakarta Sans', sans-serif",
              border: 'none',
              cursor: 'pointer',
              boxShadow: '0 8px 28px rgba(212, 175, 55, 0.45)',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '10px',
              transition: 'transform 0.2s ease, box-shadow 0.2s ease',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.04)')}
            onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
          >
            <span>RSVP for Celebration</span>
            <ArrowRight size={18} />
          </button>
        </div>
      </section>

      {/* ─── SECTION 2: IMPERIAL FARMAN (CEREMONIAL PROCLAMATION) ─── */}
      <section
        style={{
          padding: '80px 20px',
          position: 'relative',
          zIndex: 10,
        }}
      >
        <div
          style={{
            maxWidth: '680px',
            margin: '0 auto',
            padding: '48px clamp(24px, 5vw, 44px)',
            backgroundColor: 'rgba(13, 18, 43, 0.65)',
            backdropFilter: 'blur(20px)',
            borderRadius: '24px',
            border: '1.5px solid rgba(212, 175, 55, 0.35)',
            boxShadow: '0 24px 64px rgba(0, 0, 0, 0.6), inset 0 0 40px rgba(212, 175, 55, 0.06)',
            textAlign: 'center',
            position: 'relative',
          }}
        >
          {/* Top Wax Seal */}
          <div
            style={{
              position: 'absolute',
              top: '-32px',
              left: '50%',
              transform: 'translateX(-50%)',
            }}
          >
            <RoyalWaxSeal size={64} initials={crestInitials} />
          </div>

          <h3
            style={{
              fontFamily: "'Cinzel', serif",
              fontSize: 'clamp(1.4rem, 4vw, 1.85rem)',
              color: '#FFDF73',
              marginTop: '20px',
              marginBottom: '18px',
              letterSpacing: '2px',
            }}
          >
            The Royal Invitation
          </h3>

          <p
            style={{
              fontSize: 'clamp(1.05rem, 2.5vw, 1.2rem)',
              lineHeight: 1.8,
              color: 'rgba(250, 245, 238, 0.9)',
              fontStyle: 'italic',
              marginBottom: '24px',
            }}
          >
            "Two souls woven in harmony, embarking on a timeless voyage of love, honor, and laughter.
            Together with our beloved families, we welcome you to share in these cherished memories,
            auspicious prayers, and joyous festivities."
          </p>

          <p
            style={{
              fontFamily: "'Plus Jakarta Sans', sans-serif",
              fontSize: '0.85rem',
              letterSpacing: '2px',
              textTransform: 'uppercase',
              color: 'rgba(212, 175, 55, 0.8)',
              fontWeight: 600,
            }}
          >
            The Families of {p1Name} & {p2Name}
          </p>
        </div>
      </section>

      {/* ─── SECTION 3: GILDED PORTRAITS & CELEBRANT BIOS ─── */}
      <section
        style={{
          padding: '80px 20px',
          position: 'relative',
          zIndex: 10,
        }}
      >
        <div style={{ maxWidth: '840px', margin: '0 auto', textAlign: 'center' }}>
          <span
            style={{
              fontFamily: "'Plus Jakarta Sans', sans-serif",
              fontSize: '0.78rem',
              letterSpacing: '3px',
              textTransform: 'uppercase',
              color: '#D4AF37',
              display: 'block',
              marginBottom: '8px',
            }}
          >
            The Celebrants
          </span>
          <h2
            style={{
              fontFamily: "'Cinzel', serif",
              fontSize: 'clamp(2rem, 5vw, 2.8rem)',
              color: '#FFFFFF',
              marginBottom: '12px',
            }}
          >
            Honoring the Couple
          </h2>

          <RoyalFiligreeDivider color="#D4AF37" maxWidth={320} />

          {/* Side by Side Gilded Oval Medallions */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 'clamp(16px, 4vw, 48px)',
              marginTop: '40px',
              flexWrap: 'wrap',
            }}
          >
            {/* Partner 1 */}
            <div style={{ textAlign: 'center', maxWidth: '280px', flex: '1 1 240px' }}>
              <div
                style={{
                  width: 'clamp(140px, 32vw, 190px)',
                  height: 'clamp(170px, 38vw, 230px)',
                  borderRadius: '50%',
                  margin: '0 auto 18px auto',
                  padding: '6px',
                  background: 'linear-gradient(135deg, #FFDF73 0%, #D4AF37 50%, #785207 100%)',
                  boxShadow: '0 12px 36px rgba(0, 0, 0, 0.5), 0 0 20px rgba(212, 175, 55, 0.3)',
                }}
              >
                <img
                  src={p1Image}
                  alt={p1Name}
                  style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: '50%',
                    objectFit: 'cover',
                  }}
                />
              </div>

              <h3
                style={{
                  fontFamily: "'Cinzel', serif",
                  fontSize: '1.4rem',
                  color: '#FAF5EE',
                  marginBottom: '4px',
                }}
              >
                {p1Name}
              </h3>
              <span
                style={{
                  display: 'inline-block',
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  fontSize: '0.75rem',
                  letterSpacing: '2px',
                  textTransform: 'uppercase',
                  color: '#FFDF73',
                  fontWeight: 600,
                  marginBottom: '10px',
                }}
              >
                {p1Role}
              </span>
              {p1Bio && (
                <p
                  style={{
                    fontSize: '0.95rem',
                    color: 'rgba(250, 245, 238, 0.8)',
                    lineHeight: 1.5,
                    fontStyle: 'italic',
                    margin: '0 auto',
                  }}
                >
                  "{p1Bio}"
                </p>
              )}
            </div>

            {/* Central Royal Medallion */}
            <div
              style={{
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                backgroundColor: 'rgba(212, 175, 55, 0.15)',
                border: '1.5px solid #D4AF37',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#FFDF73',
                boxShadow: '0 0 24px rgba(212, 175, 55, 0.4)',
              }}
            >
              <Heart size={20} fill="#FFDF73" />
            </div>

            {/* Partner 2 */}
            <div style={{ textAlign: 'center', maxWidth: '280px', flex: '1 1 240px' }}>
              <div
                style={{
                  width: 'clamp(140px, 32vw, 190px)',
                  height: 'clamp(170px, 38vw, 230px)',
                  borderRadius: '50%',
                  margin: '0 auto 18px auto',
                  padding: '6px',
                  background: 'linear-gradient(135deg, #FFDF73 0%, #D4AF37 50%, #785207 100%)',
                  boxShadow: '0 12px 36px rgba(0, 0, 0, 0.5), 0 0 20px rgba(212, 175, 55, 0.3)',
                }}
              >
                <img
                  src={p2Image}
                  alt={p2Name}
                  style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: '50%',
                    objectFit: 'cover',
                  }}
                />
              </div>

              <h3
                style={{
                  fontFamily: "'Cinzel', serif",
                  fontSize: '1.4rem',
                  color: '#FAF5EE',
                  marginBottom: '4px',
                }}
              >
                {p2Name}
              </h3>
              <span
                style={{
                  display: 'inline-block',
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  fontSize: '0.75rem',
                  letterSpacing: '2px',
                  textTransform: 'uppercase',
                  color: '#FFDF73',
                  fontWeight: 600,
                  marginBottom: '10px',
                }}
              >
                {p2Role}
              </span>
              {p2Bio && (
                <p
                  style={{
                    fontSize: '0.95rem',
                    color: 'rgba(250, 245, 238, 0.8)',
                    lineHeight: 1.5,
                    fontStyle: 'italic',
                    margin: '0 auto',
                  }}
                >
                  "{p2Bio}"
                </p>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ─── SECTION 4: PALACE CEREMONIAL ITINERARY ─── */}
      <section
        id="regalia-itinerary"
        style={{
          padding: '80px 20px',
          position: 'relative',
          zIndex: 10,
        }}
      >
        <div style={{ maxWidth: '780px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '40px' }}>
            <span
              style={{
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                fontSize: '0.78rem',
                letterSpacing: '3px',
                textTransform: 'uppercase',
                color: '#D4AF37',
              }}
            >
              Ceremonial Schedule
            </span>
            <h2
              style={{
                fontFamily: "'Cinzel', serif",
                fontSize: 'clamp(2rem, 5vw, 2.8rem)',
                color: '#FFFFFF',
                marginTop: '6px',
              }}
            >
              Order of Events
            </h2>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {eventsList.map((ev, idx) => (
              <div
                key={ev.id || idx}
                style={{
                  padding: '28px clamp(20px, 4vw, 32px)',
                  borderRadius: '20px',
                  backgroundColor: 'rgba(13, 18, 43, 0.75)',
                  border: '1px solid rgba(212, 175, 55, 0.3)',
                  boxShadow: '0 12px 32px rgba(0, 0, 0, 0.5)',
                  backdropFilter: 'blur(16px)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '12px',
                  position: 'relative',
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
                  <h3
                    style={{
                      fontFamily: "'Cinzel', serif",
                      fontSize: '1.35rem',
                      color: '#FFDF73',
                      margin: 0,
                    }}
                  >
                    {ev.name}
                  </h3>
                  <span
                    style={{
                      fontFamily: "'Plus Jakarta Sans', sans-serif",
                      fontSize: '0.75rem',
                      padding: '4px 12px',
                      borderRadius: '9999px',
                      backgroundColor: 'rgba(212, 175, 55, 0.15)',
                      color: '#D4AF37',
                      fontWeight: 600,
                      letterSpacing: '1px',
                    }}
                  >
                    Event 0{idx + 1}
                  </span>
                </div>

                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                    gap: '12px',
                    fontSize: '0.95rem',
                    color: '#E5E7EB',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Clock size={16} color="#D4AF37" />
                    <span>{ev.time}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <MapPin size={16} color="#D4AF37" />
                    <span>{ev.venue || venueNameStr}</span>
                  </div>
                </div>

                {ev.description && (
                  <p style={{ margin: 0, fontSize: '0.95rem', color: 'rgba(250, 245, 238, 0.8)', fontStyle: 'italic', lineHeight: 1.5 }}>
                    {ev.description}
                  </p>
                )}

                {ev.dressCode && (
                  <div style={{ fontSize: '0.85rem', color: '#FFDF73', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    <Sparkles size={14} style={{ display: 'inline', marginRight: '6px' }} />
                    Dress Code: {ev.dressCode}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Venue & Directions Action */}
          <div style={{ textAlign: 'center', marginTop: '32px' }}>
            <a
              href={`https://maps.google.com/?q=${encodeURIComponent(venueFullAddress)}`}
              target="_blank"
              rel="noreferrer"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '12px 28px',
                borderRadius: '9999px',
                backgroundColor: 'rgba(212, 175, 55, 0.12)',
                border: '1px solid #D4AF37',
                color: '#FFDF73',
                fontSize: '0.9rem',
                textDecoration: 'none',
                fontWeight: 600,
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                transition: 'all 0.2s ease',
              }}
            >
              <MapPin size={16} />
              <span>Get Palace Directions on Google Maps</span>
            </a>
          </div>
        </div>
      </section>

      {/* ─── SECTION 5: DIGITAL SHAGUN & BLESSINGS REGISTRY ─── */}
      <section
        style={{
          padding: '80px 20px',
          position: 'relative',
          zIndex: 10,
        }}
      >
        <div
          style={{
            maxWidth: '680px',
            margin: '0 auto',
            padding: '40px clamp(20px, 4vw, 36px)',
            backgroundColor: 'rgba(13, 18, 43, 0.8)',
            border: '1px solid rgba(212, 175, 55, 0.35)',
            borderRadius: '24px',
            textAlign: 'center',
          }}
        >
          <div
            style={{
              width: '54px',
              height: '54px',
              borderRadius: '50%',
              backgroundColor: 'rgba(212, 175, 55, 0.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 16px auto',
              color: '#FFDF73',
            }}
          >
            <Gift size={24} />
          </div>

          <h3 style={{ fontFamily: "'Cinzel', serif", fontSize: '1.8rem', color: '#FFDF73', marginBottom: '8px' }}>
            Blessings & Traditional Shagun
          </h3>
          <p style={{ color: 'rgba(250, 245, 238, 0.8)', fontSize: '1rem', fontStyle: 'italic', maxWidth: '480px', margin: '0 auto 24px auto', lineHeight: 1.6 }}>
            Your loving presence is our most cherished gift. For guests wishing to bestow a traditional Shagun blessing:
          </p>

          <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '24px' }}>
            {[501, 1100, 2100, 5100, 11000].map((amt) => (
              <button
                key={amt}
                type="button"
                onClick={() => setSelectedShagun(amt)}
                style={{
                  padding: '10px 20px',
                  borderRadius: '12px',
                  backgroundColor: selectedShagun === amt ? '#D4AF37' : 'rgba(255, 255, 255, 0.05)',
                  color: selectedShagun === amt ? '#060814' : '#FFDF73',
                  border: '1px solid rgba(212, 175, 55, 0.4)',
                  fontWeight: 700,
                  fontSize: '0.95rem',
                  cursor: 'pointer',
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                }}
              >
                ₹{amt.toLocaleString('en-IN')}
              </button>
            ))}
          </div>

          {shagunSent ? (
            <div style={{ padding: '16px', borderRadius: '12px', backgroundColor: 'rgba(52, 211, 153, 0.15)', color: '#34D399', fontSize: '0.95rem' }}>
              <Check size={18} style={{ display: 'inline', marginRight: '6px' }} />
              Thank you for your generous Shagun blessing of ₹{selectedShagun.toLocaleString('en-IN')}!
            </div>
          ) : (
            <button
              onClick={() => setShagunSent(true)}
              style={{
                padding: '14px 36px',
                borderRadius: '9999px',
                backgroundColor: '#D4AF37',
                color: '#060814',
                border: 'none',
                fontWeight: 700,
                fontSize: '0.95rem',
                letterSpacing: '1px',
                cursor: 'pointer',
                fontFamily: "'Plus Jakarta Sans', sans-serif",
              }}
            >
              Bestow Shagun (₹{selectedShagun.toLocaleString('en-IN')})
            </button>
          )}
        </div>
      </section>

      {/* ─── SECTION 6: ROYAL VELVET RSVP ─── */}
      <section
        id="regalia-rsvp"
        style={{
          padding: '80px 20px',
          position: 'relative',
          zIndex: 10,
        }}
      >
        <div
          style={{
            maxWidth: '620px',
            margin: '0 auto',
            padding: '48px clamp(20px, 5vw, 40px)',
            backgroundColor: 'rgba(13, 18, 43, 0.85)',
            backdropFilter: 'blur(24px)',
            borderRadius: '24px',
            border: '1.5px solid rgba(212, 175, 55, 0.4)',
            boxShadow: '0 24px 64px rgba(0, 0, 0, 0.6)',
          }}
        >
          <div style={{ textAlign: 'center', marginBottom: '32px' }}>
            <span
              style={{
                fontFamily: "'Plus Jakarta Sans', sans-serif",
                fontSize: '0.78rem',
                letterSpacing: '3px',
                textTransform: 'uppercase',
                color: '#D4AF37',
              }}
            >
              Response Required
            </span>
            <h2
              style={{
                fontFamily: "'Cinzel', serif",
                fontSize: 'clamp(1.8rem, 4.5vw, 2.4rem)',
                color: '#FFFFFF',
                marginTop: '6px',
              }}
            >
              Royal RSVP Confirmation
            </h2>
            <p style={{ color: 'rgba(250, 245, 238, 0.8)', fontSize: '0.95rem', fontStyle: 'italic', margin: '8px auto 0 auto' }}>
              Kindly confirm your auspicious presence by {eventDateStr}
            </p>
          </div>

          {rsvpSubmitted ? (
            <div style={{ textAlign: 'center', padding: '30px 0' }}>
              <div
                style={{
                  width: '64px',
                  height: '64px',
                  borderRadius: '50%',
                  backgroundColor: 'rgba(212, 175, 55, 0.15)',
                  color: '#FFDF73',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 16px auto',
                  border: '1px solid #D4AF37',
                }}
              >
                <CheckCircle2 size={36} />
              </div>
              <h3 style={{ fontFamily: "'Cinzel', serif", fontSize: '1.8rem', color: '#FAF5EE', marginBottom: '8px' }}>
                Your Honor is Reserved
              </h3>
              <p style={{ color: 'rgba(250, 245, 238, 0.8)', fontSize: '1rem', fontStyle: 'italic', marginBottom: '24px' }}>
                Thank you, <strong>{guestName}</strong>. Your confirmation has been formally recorded with the host families.
              </p>
              <button
                onClick={() => setRsvpSubmitted(false)}
                style={{
                  padding: '10px 24px',
                  borderRadius: '9999px',
                  backgroundColor: 'transparent',
                  color: '#FFDF73',
                  border: '1px solid rgba(212, 175, 55, 0.4)',
                  cursor: 'pointer',
                  fontSize: '0.85rem',
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                }}
              >
                Modify RSVP
              </button>
            </div>
          ) : (
            <form onSubmit={handleRsvpSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.8rem', letterSpacing: '1px', textTransform: 'uppercase', color: '#FFDF73', marginBottom: '6px', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  Your Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Maharaja Vikram Singh"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '14px 16px',
                    borderRadius: '12px',
                    backgroundColor: 'rgba(6, 8, 20, 0.6)',
                    border: '1px solid rgba(212, 175, 55, 0.3)',
                    color: '#fff',
                    fontFamily: 'inherit',
                    fontSize: '1rem',
                  }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.8rem', letterSpacing: '1px', textTransform: 'uppercase', color: '#FFDF73', marginBottom: '6px', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  Contact (Email or Phone) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="vikram@singh.in"
                  value={guestContact}
                  onChange={(e) => setGuestContact(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '14px 16px',
                    borderRadius: '12px',
                    backgroundColor: 'rgba(6, 8, 20, 0.6)',
                    border: '1px solid rgba(212, 175, 55, 0.3)',
                    color: '#fff',
                    fontFamily: 'inherit',
                    fontSize: '1rem',
                  }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: allowPlusOneGuest ? '1fr 1fr' : '1fr', gap: '16px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.8rem', letterSpacing: '1px', textTransform: 'uppercase', color: '#FFDF73', marginBottom: '6px', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    Attendance
                  </label>
                  <select
                    value={attendingStatus}
                    onChange={(e: any) => setAttendingStatus(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '14px 16px',
                      borderRadius: '12px',
                      backgroundColor: 'rgba(6, 8, 20, 0.9)',
                      border: '1px solid rgba(212, 175, 55, 0.3)',
                      color: '#fff',
                      fontFamily: 'inherit',
                      fontSize: '1rem',
                    }}
                  >
                    <option value="ATTENDING">Joyfully Attending</option>
                    <option value="DECLINED">Regretfully Decline</option>
                  </select>
                </div>

                {allowPlusOneGuest && (
                  <div>
                    <label style={{ display: 'block', fontSize: '0.8rem', letterSpacing: '1px', textTransform: 'uppercase', color: '#FFDF73', marginBottom: '6px', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                      Guest Headcount
                    </label>
                    <select
                      value={partySize}
                      onChange={(e) => setPartySize(parseInt(e.target.value, 10))}
                      style={{
                        width: '100%',
                        padding: '14px 16px',
                        borderRadius: '12px',
                        backgroundColor: 'rgba(6, 8, 20, 0.9)',
                        border: '1px solid rgba(212, 175, 55, 0.3)',
                        color: '#fff',
                        fontFamily: 'inherit',
                        fontSize: '1rem',
                      }}
                    >
                      <option value={1}>1 Guest</option>
                      <option value={2}>2 Guests (Couple)</option>
                      <option value={3}>3 Guests (Family)</option>
                      <option value={4}>4 Guests (Family)</option>
                    </select>
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                style={{
                  marginTop: '12px',
                  padding: '16px',
                  borderRadius: '9999px',
                  background: 'linear-gradient(135deg, #FFDF73 0%, #D4AF37 50%, #B38728 100%)',
                  color: '#060814',
                  fontWeight: 700,
                  fontSize: '1rem',
                  letterSpacing: '2px',
                  textTransform: 'uppercase',
                  border: 'none',
                  cursor: isSubmitting ? 'wait' : 'pointer',
                  fontFamily: "'Plus Jakarta Sans', sans-serif",
                  boxShadow: '0 8px 24px rgba(212, 175, 55, 0.4)',
                }}
              >
                {isSubmitting ? 'Recording RSVP...' : 'Confirm Auspicious Presence'}
              </button>
            </form>
          )}
        </div>
      </section>

      {/* ─── SECTION 7: IMPERIAL WISHES GUESTBOOK ─── */}
      <section
        style={{
          padding: '80px 20px',
          position: 'relative',
          zIndex: 10,
        }}
      >
        <div style={{ maxWidth: '820px', margin: '0 auto' }}>
          <WishesGuestbookSection
            section={wishesSection}
            theme={theme}
            experienceId={experience.id}
            tenantId={experience.tenantId}
          />
        </div>
      </section>

      {/* ─── LUXURY REGAL FOOTER ─── */}
      <footer
        style={{
          padding: '60px 20px',
          textAlign: 'center',
          borderTop: '1px solid rgba(212, 175, 55, 0.25)',
          position: 'relative',
          zIndex: 10,
          backgroundColor: 'rgba(6, 8, 20, 0.95)',
        }}
      >
        <RoyalWaxSeal size={48} initials={crestInitials} />
        <h4 style={{ fontFamily: "'Cinzel', serif", fontSize: '1.4rem', color: '#FFDF73', margin: '14px 0 6px 0' }}>
          {coupleNames}
        </h4>
        <p style={{ color: 'rgba(250, 245, 238, 0.6)', fontSize: '0.9rem', fontStyle: 'italic', margin: 0 }}>
          {eventDateStr} • {venueLocation}
        </p>
      </footer>
    </div>
  );
}
