'use client';

import React from 'react';

interface CoupleTitleProps {
  title?: string;
  as?: 'h1' | 'h2' | 'h3' | 'div' | 'span';
  className?: string;
  style?: React.CSSProperties;
  nameStyle?: React.CSSProperties;
  ampersandStyle?: React.CSSProperties;
  flourishColor?: string;
  showFlourish?: boolean;
}

/**
 * Parses names separated by '&', 'and', or '+'
 * Also extracts trailing event suffixes (e.g. "Wedding", "Celebration") from name2
 * so partner names remain optically balanced.
 */
export function parseCoupleNames(title?: string): {
  isCouple: boolean;
  name1: string;
  name2: string;
  ampersand: string;
  suffix: string;
} {
  if (!title) return { isCouple: false, name1: '', name2: '', ampersand: '&', suffix: '' };

  const extractSuffix = (name: string): { cleanName: string; suffix: string } => {
    const eventRegex = /\s+(Wedding|Reception|Nuptials|Marriage|Engagement|Celebration|Union)$/i;
    const match = name.match(eventRegex);
    if (match && match[1]) {
      return {
        cleanName: name.replace(eventRegex, '').trim(),
        suffix: match[1].trim(),
      };
    }
    return { cleanName: name.trim(), suffix: '' };
  };

  // Match " & "
  if (title.includes(' & ')) {
    const parts = title.split(' & ');
    const first = parts[0] || '';
    const secondRaw = parts.slice(1).join(' & ');
    const { cleanName: second, suffix } = extractSuffix(secondRaw);
    return {
      isCouple: Boolean(first.trim() && second),
      name1: first.trim(),
      name2: second,
      ampersand: '&',
      suffix,
    };
  }

  // Match " and " (case-insensitive word boundary)
  if (/\s+and\s+/i.test(title)) {
    const parts = title.split(/\s+and\s+/i);
    const first = parts[0] || '';
    const secondRaw = parts.slice(1).join(' & ');
    const { cleanName: second, suffix } = extractSuffix(secondRaw);
    return {
      isCouple: Boolean(first.trim() && second),
      name1: first.trim(),
      name2: second,
      ampersand: '&',
      suffix,
    };
  }

  // Match " + "
  if (title.includes(' + ')) {
    const parts = title.split(' + ');
    const first = parts[0] || '';
    const secondRaw = parts.slice(1).join(' + ');
    const { cleanName: second, suffix } = extractSuffix(secondRaw);
    return {
      isCouple: Boolean(first.trim() && second),
      name1: first.trim(),
      name2: second,
      ampersand: '&',
      suffix,
    };
  }

  const { cleanName, suffix } = extractSuffix(title);
  return { isCouple: false, name1: cleanName, name2: '', ampersand: '&', suffix };
}

/**
 * Typographic Couple Title component:
 * Elegantly splits partner names across lines with a centered ampersand '&' on the middle line,
 * ensuring each person's name is completely visible, beautifully balanced, and prominent.
 */
export function CoupleTitle({
  title = '',
  as: Component = 'h1',
  className = '',
  style = {},
  nameStyle = {},
  ampersandStyle = {},
  flourishColor,
  showFlourish = true,
}: CoupleTitleProps) {
  const { isCouple, name1, name2, ampersand, suffix } = parseCoupleNames(title);

  if (!isCouple || !name1 || !name2) {
    return (
      <Component className={className} style={style}>
        {title}
      </Component>
    );
  }

  const containerStyle: React.CSSProperties = {
    display: 'block',
    textAlign: 'center',
    width: '100%',
    margin: 0,
    padding: 0,
    ...style,
  };

  return (
    <Component className={className} style={containerStyle}>
      {/* Partner 1 Full Name */}
      <span
        className="couple-name couple-name-1"
        style={{
          display: 'block',
          width: '100%',
          lineHeight: 1.12,
          textWrap: 'balance',
          wordBreak: 'break-word',
          overflowWrap: 'break-word',
          background: 'inherit',
          WebkitBackgroundClip: 'inherit',
          WebkitTextFillColor: 'inherit',
          ...nameStyle,
        }}
      >
        {name1}
      </span>

      {/* Middle Ampersand Line */}
      <span
        className="couple-ampersand-row"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 'clamp(8px, 1.8vw, 18px)',
          margin: 'clamp(2px, 0.4vh, 6px) 0',
          fontSize: '0.55em',
          lineHeight: 1,
          fontStyle: 'italic',
          fontFamily: "'Cormorant Garamond', 'Playfair Display', Georgia, serif",
          opacity: 0.92,
          userSelect: 'none',
          ...ampersandStyle,
        }}
      >
        {showFlourish && (
          <span
            style={{
              display: 'inline-block',
              width: 'clamp(18px, 3.2vw, 42px)',
              height: '1px',
              background: flourishColor || (style.color as string) || '#E8B86D',
              opacity: 0.45,
              WebkitTextFillColor: 'initial',
            }}
          />
        )}
        <span
          style={{
            fontStyle: 'italic',
            fontWeight: 400,
            transform: 'translateY(-1px)',
            display: 'inline-block',
            background: 'inherit',
            WebkitBackgroundClip: 'inherit',
            WebkitTextFillColor: 'inherit',
          }}
        >
          {ampersand}
        </span>
        {showFlourish && (
          <span
            style={{
              display: 'inline-block',
              width: 'clamp(18px, 3.2vw, 42px)',
              height: '1px',
              background: flourishColor || (style.color as string) || '#E8B86D',
              opacity: 0.45,
              WebkitTextFillColor: 'initial',
            }}
          />
        )}
      </span>

      {/* Partner 2 Full Name */}
      <span
        className="couple-name couple-name-2"
        style={{
          display: 'block',
          width: '100%',
          lineHeight: 1.12,
          textWrap: 'balance',
          wordBreak: 'break-word',
          overflowWrap: 'break-word',
          background: 'inherit',
          WebkitBackgroundClip: 'inherit',
          WebkitTextFillColor: 'inherit',
          ...nameStyle,
        }}
      >
        {name2}
      </span>

      {/* Optional Event Suffix (e.g. "Wedding", "Celebration") */}
      {suffix && (
        <span
          className="couple-event-suffix"
          style={{
            display: 'block',
            fontSize: '0.34em',
            letterSpacing: 'clamp(3px, 0.8vw, 6px)',
            textTransform: 'uppercase',
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 600,
            color: flourishColor || '#E8A598',
            marginTop: 'clamp(6px, 1.2vh, 12px)',
            opacity: 0.85,
            WebkitTextFillColor: 'initial',
          }}
        >
          {suffix}
        </span>
      )}
    </Component>
  );
}
