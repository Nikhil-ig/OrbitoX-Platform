'use client';

import React, { use, useState, useEffect } from 'react';
import {
  DEFAULT_THEMES,
  DEFAULT_OCCASIONS,
  Experience,
  ExperienceSection,
  SectionEngine,
  Theme,
} from '@orbitox-io/celebrations';
import { ExperienceView } from '@/components/renderer/ExperienceView';
import { Loader2 } from 'lucide-react';

const sectionEngine = new SectionEngine();

function parseSlugToCelebration(slug: string): {
  names: string;
  occasionSlug: string;
  occasionName: string;
} {
  const parts = slug.toLowerCase().split('-');
  const knownOccasions = ['wedding', 'birthday', 'engagement', 'anniversary', 'baby-shower', 'festival'];
  let occasionSlug = 'wedding';
  let occasionName = 'Wedding';

  const matchedOcc = knownOccasions.find((o) => parts.includes(o));
  if (matchedOcc) {
    occasionSlug = matchedOcc;
    const foundOcc = DEFAULT_OCCASIONS.find((o) => o.slug === matchedOcc);
    if (foundOcc) occasionName = foundOcc.name;
  }

  // Filter out occasion / filler words to extract names
  const nameParts = parts.filter(
    (p) => !['wedding', 'birthday', 'engagement', 'anniversary', 'baby', 'shower', 'festival', 'celebration', 'party', 'demo', 'royal', 'experience'].includes(p)
  );

  let names = 'Vikramaditya & Ananya';
  const name0 = nameParts[0];
  const name1 = nameParts[1];
  const name2 = nameParts[2];

  if (nameParts.length === 2 && name0 && name1) {
    const p1 = name0.charAt(0).toUpperCase() + name0.slice(1);
    const p2 = name1.charAt(0).toUpperCase() + name1.slice(1);
    names = `${p1} & ${p2}`;
  } else if (nameParts.length >= 3 && name0 && name1 === 'and' && name2) {
    const p1 = name0.charAt(0).toUpperCase() + name0.slice(1);
    const p2 = name2.charAt(0).toUpperCase() + name2.slice(1);
    names = `${p1} & ${p2}`;
  } else if (nameParts.length > 0) {
    names = nameParts
      .filter((p): p is string => Boolean(p))
      .map((p) => p.charAt(0).toUpperCase() + p.slice(1))
      .join(' ');
  }

  return { names, occasionSlug, occasionName };
}

function buildFallbackExperience(slug: string): Experience {
  const { names, occasionSlug, occasionName } = parseSlugToCelebration(slug);
  const defaultTheme: Theme =
    DEFAULT_THEMES.find((t) => t.slug === 'royal-regalia') || (DEFAULT_THEMES[0] as Theme);

  const defaultSections = sectionEngine.buildDefaultSections([
    'hero',
    'countdown',
    'couple_profile',
    'story',
    'events_schedule',
    'venue_map',
    'dress_code',
    'gallery',
    'gift_registry',
    'live_poll',
    'rsvp',
    'wishes_guestbook',
  ]);

  const nameList = names.includes('&') ? names.split('&').map((s) => s.trim()) : [names, ''];
  const p1 = nameList[0] || 'Aarav';
  const p2 = nameList[1] || 'Meera';

  const enrichedSections: ExperienceSection[] = defaultSections.map((sec) => {
    if (sec.sectionType === 'hero') {
      return {
        ...sec,
        config: {
          ...sec.config,
          hostNames: names,
          headline: occasionSlug === 'birthday' ? `Celebrating ${p1}!` : 'We are getting married!',
          subheadline: 'Together with our families, we invite you to celebrate',
          eventDate: '2026-12-18',
          venueCity: 'Udaipur, Rajasthan',
          venueName: 'Jagmandir Island Palace',
        },
      };
    }
    if (sec.sectionType === 'couple_profile') {
      return {
        ...sec,
        config: {
          ...sec.config,
          partner1Name: p1,
          partner1Role: occasionSlug === 'wedding' ? 'The Groom' : 'Celebrant',
          partner2Name: p2,
          partner2Role: occasionSlug === 'wedding' ? 'The Bride' : 'Guest of Honor',
        },
      };
    }
    if (sec.sectionType === 'wishes_guestbook') {
      return {
        ...sec,
        config: {
          ...sec.config,
          hostNames: names,
          subtitle: `Leave your love, blessings, and memorable advice for ${names}`,
        },
      };
    }
    return sec;
  });

  return {
    id: `exp_dynamic_${slug}`,
    tenantId: 'tenant_royal_celebration',
    title: `${names} ${occasionName} Celebration`,
    slug: slug,
    occasionId: `occ_${occasionSlug}`,
    occasionSlug: occasionSlug,
    themeId: slug.includes('celestial')
      ? 'theme_celestial_rose_gold'
      : defaultTheme.id,
    themeSlug: slug.includes('celestial')
      ? 'celestial-rose-gold'
      : defaultTheme.slug,
    templateSlug: slug.includes('celestial')
      ? 'celestial-parallax'
      : slug.includes('amalfi')
        ? 'amalfi-riviera'
        : slug.includes('glasshouse')
          ? 'enchanted-glasshouse'
          : slug.includes('doors')
            ? 'romantic-doors'
            : slug.includes('regalia') || slug.includes('royal')
              ? 'royal-regalia'
              : slug.includes('party') || slug.includes('nocturne')
                ? 'party-nocturne'
                : 'royal-regalia',
    status: 'PUBLISHED',
    eventDate: '2026-12-18',
    sections: enrichedSections,
    featuresEnabled: ['rsvp_tracking', 'photo_gallery', 'wishes_wall', 'background_music'],
    passwordProtection: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

export default function ExperiencePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const resolvedParams = use(params);
  const slug = resolvedParams.slug;

  // Initialize from client storage immediately to eliminate content delay
  const [experience, setExperience] = useState<Experience | null>(() => {
    if (typeof window !== 'undefined') {
      try {
        const cached = localStorage.getItem(`orbitox_exp_${slug}`);
        if (cached) {
          return JSON.parse(cached) as Experience;
        }
      } catch (e) {
        console.warn('Could not read cached experience from localStorage:', e);
      }
    }
    return null;
  });

  const [isLoading, setIsLoading] = useState(!experience);

  // Fetch experience from backend API with fallback
  useEffect(() => {
    let isMounted = true;

    async function loadExperience() {
      try {
        const res = await fetch(`/api/experiences?slug=${encodeURIComponent(slug)}`);
        if (res.ok) {
          const data = await res.json();
          if (data.success && data.experience && isMounted) {
            setExperience(data.experience);
            if (typeof window !== 'undefined') {
              localStorage.setItem(`orbitox_exp_${slug}`, JSON.stringify(data.experience));
            }
            setIsLoading(false);
            return;
          }
        }
      } catch (err) {
        console.warn('Failed to fetch experience from API:', err);
      }

      // If neither API nor localStorage yielded an experience, generate smart fallback based on slug
      if (isMounted) {
        setExperience((prev) => prev || buildFallbackExperience(slug));
        setIsLoading(false);
      }
    }

    loadExperience();

    return () => {
      isMounted = false;
    };
  }, [slug]);

  if (isLoading || !experience) {
    return (
      <div
        style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#07090E',
          color: 'var(--cel-gold, #D4AF37)',
          fontFamily: "'Cinzel', serif",
        }}
      >
        <Loader2 size={36} className="animate-spin" style={{ marginBottom: '16px' }} />
        <span style={{ letterSpacing: '3px', fontSize: '1rem', textTransform: 'uppercase' }}>
          Preparing Celebration Experience...
        </span>
      </div>
    );
  }

  // Resolve active Theme
  const theme: Theme =
    DEFAULT_THEMES.find(
      (t) => t.slug === experience.themeSlug || t.id === experience.themeId
    ) || (DEFAULT_THEMES[0] as Theme);

  return <ExperienceView experience={experience} theme={theme} />;
}
