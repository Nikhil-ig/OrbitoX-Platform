'use client';

import React, { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { CreationStudio } from '@/components/studio/CreationStudio';

function CreateContent() {
  const searchParams = useSearchParams();
  const occasion = searchParams.get('occasion') || undefined;
  const theme = searchParams.get('theme') || undefined;

  return <CreationStudio initialOccasionSlug={occasion} initialThemeSlug={theme} />;
}

export default function CreatePage() {
  return (
    <Suspense
      fallback={
        <div
          style={{
            minHeight: '100vh',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            background: 'var(--color-bg)',
            color: 'var(--color-accent)',
            gap: 16,
          }}
        >
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: '50%',
              border: '2px solid rgba(124, 92, 252, 0.2)',
              borderTopColor: 'var(--color-accent)',
              animation: 'spin 1s linear infinite',
            }}
          />
          <span style={{ fontSize: 13, letterSpacing: '0.08em', color: 'var(--color-text-secondary)' }}>
            Loading Creation Studio...
          </span>
        </div>
      }
    >
      <CreateContent />
    </Suspense>
  );
}
