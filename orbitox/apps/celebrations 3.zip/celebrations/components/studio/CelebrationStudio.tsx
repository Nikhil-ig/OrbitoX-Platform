'use client';

import React, { useState, useEffect, useMemo } from 'react';
import {
  CelebrationState,
  ViewportMode,
  WorkflowArea,
  OCCASION_PRESETS,
  buildLiveExperience,
} from './StudioData';
import { StudioWorkflowRail } from './StudioWorkflowRail';
import { CelebrationLiveCanvas } from './CelebrationLiveCanvas';
import { ContextualInspector } from './ContextualInspector';
import { PublishCelebrationModal } from './PublishCelebrationModal';
import { FullGuestPreviewModal } from './FullGuestPreviewModal';
import {
  Monitor,
  Tablet,
  Smartphone,
  Eye,
  Rocket,
  Sparkles,
  SlidersHorizontal,
} from 'lucide-react';
import Link from 'next/link';

export function CelebrationStudio() {
  const weddingPreset = OCCASION_PRESETS['wedding'];

  const [state, setState] = useState<CelebrationState>({
    occasion: 'wedding',
    theme: 'royal-regalia',
    title: 'Aarav & Meera Wedding Celebration',
    protagonist1: weddingPreset.defaultProtagonist1,
    protagonist1Role: weddingPreset.defaultProtagonist1Role,
    protagonist1Bio: 'Architect, heritage enthusiast, and classical guitarist.',
    protagonist1Image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=85',
    protagonist2: weddingPreset.defaultProtagonist2,
    protagonist2Role: weddingPreset.defaultProtagonist2Role,
    protagonist2Bio: 'Classical Kathak dancer, wildlife conservationist, and book lover.',
    protagonist2Image: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600&q=85',
    tagline: weddingPreset.defaultTagline,
    date: '2027-02-18',
    time: '06:00 PM IST',
    venueName: weddingPreset.defaultVenue,
    venueAddress: 'Palace Road, Cantt Area, Jodhpur, Rajasthan 342006',
    city: weddingPreset.defaultCity,
    stateCountry: 'Rajasthan, India',
    guestCountTarget: 150,
    storyQuote: weddingPreset.defaultQuote,
    storyBody: weddingPreset.defaultStory,
    itinerary: weddingPreset.itinerary,
    enableCountdown: true,
    enableCoupleProfile: true,
    enableItinerary: true,
    enableStory: true,
    enableVenueMap: true,
    enableDressCode: true,
    enableGallery: true,
    enableRsvp: true,
    enableShagun: true,
    enableGuestbook: true,
    enableMusic: true,
    rsvpDeadline: '10 January 2027',
    allowPlusOnes: 'yes',
    enableDietary: true,
    upiId: 'aarav.meera@okhdfcbank',
    shagunAmounts: [1001, 2100, 5100, 11000],
    hasPasscodeProtection: false,
    passcode: '2027',
    previewMode: 'experience',
  });

  const [activeArea, setActiveArea] = useState<WorkflowArea>('occasion');
  const [viewport, setViewport] = useState<ViewportMode>('desktop');
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [isFullPreviewOpen, setIsFullPreviewOpen] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving'>('saved');
  const [isInspectorOpen, setIsInspectorOpen] = useState(true);
  const [jumpTrigger, setJumpTrigger] = useState<string | undefined>(undefined);

  const handleJumpToCanvas = (area: WorkflowArea) => {
    setJumpTrigger(`${area}-${Date.now()}`);
  };

  // Construct live experience object
  const liveExperience = useMemo(() => {
    return buildLiveExperience(state);
  }, [state]);

  // Real-time synchronization to localStorage so /e/preview works instantly
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const payload = JSON.stringify(liveExperience);
        localStorage.setItem('orbitox_exp_preview', payload);
        localStorage.setItem('orbitox_exp_live-studio-preview', payload);
      } catch (e) {
        console.warn('Could not sync draft to localStorage:', e);
      }
    }
  }, [liveExperience]);

  // Auto-save feedback loop simulation
  const handleStateChange = (patch: Partial<CelebrationState>) => {
    setSaveStatus('saving');
    setState((prev) => ({ ...prev, ...patch }));
    setTimeout(() => {
      setSaveStatus('saved');
    }, 300);
  };

  // Keyboard shortcuts (Cmd+S to save, Esc to exit full preview)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 's') {
        e.preventDefault();
        setSaveStatus('saving');
        setTimeout(() => setSaveStatus('saved'), 300);
      }
      if (e.key === 'Escape' && isFullPreviewOpen) {
        setIsFullPreviewOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullPreviewOpen]);

  return (
    <div className="cs-workspace">
      {/* ─── QUIET PROFESSIONAL TOP BAR ─── */}
      <header className="cs-topbar">
        {/* Left: Brand & Active Celebration Title */}
        <div className="cs-topbar-left">
          <Link href="/" className="cs-brand-link" title="Return to Celebrations platform">
            <div className="cs-brand-icon-box">
              <Sparkles size={16} />
            </div>
            <span>Celebrations</span>
          </Link>

          <span className="cs-topbar-sep" />

          <div className="cs-celebration-title-group">
            <span className="cs-celebration-name">
              {state.protagonist1} {state.protagonist2 && `& ${state.protagonist2}`}
            </span>
            <span className="cs-celebration-tag">• {state.occasion} Studio</span>
          </div>

          <div className="cs-save-status">
            <span
              className={`cs-save-indicator ${saveStatus === 'saving' ? 'saving' : ''}`}
            />
            <span>{saveStatus === 'saving' ? 'Saving...' : 'Draft saved'}</span>
          </div>
        </div>

        {/* Center: Viewport Mode Switcher */}
        <div className="cs-viewport-switcher">
          <button
            type="button"
            onClick={() => setViewport('desktop')}
            className={`cs-viewport-btn ${viewport === 'desktop' ? 'active' : ''}`}
            title="Desktop Guest Composition"
          >
            <Monitor size={14} />
            <span>Desktop</span>
          </button>
          <button
            type="button"
            onClick={() => setViewport('tablet')}
            className={`cs-viewport-btn ${viewport === 'tablet' ? 'active' : ''}`}
            title="Tablet Composition"
          >
            <Tablet size={14} />
            <span>Tablet</span>
          </button>
          <button
            type="button"
            onClick={() => setViewport('mobile')}
            className={`cs-viewport-btn ${viewport === 'mobile' ? 'active' : ''}`}
            title="Mobile Composition"
          >
            <Smartphone size={14} />
            <span>Mobile</span>
          </button>
        </div>

        {/* Right: Actions */}
        <div className="cs-topbar-right">
          <button
            type="button"
            onClick={() => setIsInspectorOpen(!isInspectorOpen)}
            className="cs-btn-icon-toggle"
            title="Toggle Contextual Inspector"
          >
            <SlidersHorizontal size={15} />
          </button>

          {/* Full Immersion Guest View Button (Replaces broken /events link) */}
          <button
            type="button"
            onClick={() => setIsFullPreviewOpen(true)}
            className="cs-btn-ghost"
            title="Open Full Immersion Guest View"
          >
            <Eye size={14} />
            <span>Guest View</span>
          </button>

          <button
            type="button"
            onClick={() => setIsPublishModalOpen(true)}
            className="cs-btn-publish-milestone"
          >
            <Rocket size={14} />
            <span>Publish</span>
          </button>
        </div>
      </header>

      {/* ─── THREE-ZONE CREATIVE WORKSPACE BODY ─── */}
      <div className="cs-workspace-body">
        {/* Zone 1: Left Creation Journey Rail */}
        <StudioWorkflowRail
          activeArea={activeArea}
          onSelectArea={(area) => {
            setActiveArea(area);
            setIsInspectorOpen(true);
          }}
          state={state}
          onOpenPreview={() => setIsFullPreviewOpen(true)}
          onOpenPublish={() => setIsPublishModalOpen(true)}
        />

        {/* Zone 2: Central Live Celebration Canvas (Actual Celebration Engine) */}
        <main style={{ flex: 1, display: 'flex', overflow: 'hidden', position: 'relative' }}>
          <CelebrationLiveCanvas
            state={state}
            viewport={viewport}
            activeArea={activeArea}
            jumpTrigger={jumpTrigger}
            onSelectArea={(area) => {
              setActiveArea(area);
              setIsInspectorOpen(true);
            }}
            onOpenFullPreview={() => setIsFullPreviewOpen(true)}
          />
        </main>

        {/* Zone 3: Right Contextual Inspector */}
        {isInspectorOpen && (
          <ContextualInspector
            activeArea={activeArea}
            state={state}
            onChange={handleStateChange}
            onSelectArea={setActiveArea}
            onJumpToCanvas={handleJumpToCanvas}
          />
        )}
      </div>

      {/* Full Immersion Guest Preview Modal */}
      <FullGuestPreviewModal
        isOpen={isFullPreviewOpen}
        onClose={() => setIsFullPreviewOpen(false)}
        experience={liveExperience}
        themeSlug={state.theme}
      />

      {/* Publish Celebration Launch Modal */}
      <PublishCelebrationModal
        isOpen={isPublishModalOpen}
        onClose={() => setIsPublishModalOpen(false)}
        state={state}
      />
    </div>
  );
}
