'use client';

import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  CelebrationState,
  ViewportMode,
  WorkflowArea,
  THEME_PRESETS,
  OCCASION_PRESETS,
  buildLiveExperience,
} from './StudioData';
import { DEFAULT_THEMES, Theme } from '@orbitox-io/celebrations';

// Import the 8 authentic luxury celebration universe templates
import { RoyalRegaliaExperience } from '../renderer/templates/regalia/RoyalRegaliaExperience';
import { CelestialParallaxExperience } from '../renderer/templates/celestial/CelestialParallaxExperience';
import { MinimalEditorialExperience } from '../renderer/templates/editorial/MinimalEditorialExperience';
import { EnchantedGlasshouseExperience } from '../renderer/templates/glasshouse/EnchantedGlasshouseExperience';
import { AmalfiRivieraExperience } from '../renderer/templates/amalfi/AmalfiRivieraExperience';
import { PartyNocturneExperience } from '../renderer/templates/nocturne/PartyNocturneExperience';
import { RomanticDoorsExperience } from '../renderer/templates/doors/RomanticDoorsExperience';
import { SurrealOrganimoExperience } from '../renderer/templates/organimo/SurrealOrganimoExperience';
import { WelcomeDoorDispatcher } from '../renderer/doors/WelcomeDoorDispatcher';

import {
  Sparkles,
  Eye,
  Key,
  RotateCcw,
  Maximize2,
  Users,
  Calendar,
  Feather,
  MapPin,
  HeartHandshake,
  Gift,
  PenTool,
} from 'lucide-react';

interface CelebrationLiveCanvasProps {
  state: CelebrationState;
  viewport: ViewportMode;
  activeArea?: WorkflowArea;
  jumpTrigger?: string;
  onSelectArea?: (area: WorkflowArea) => void;
  onOpenFullPreview?: () => void;
}

export function CelebrationLiveCanvas({
  state,
  viewport,
  activeArea,
  jumpTrigger,
  onSelectArea,
  onOpenFullPreview,
}: CelebrationLiveCanvasProps) {
  const [previewDoorMode, setPreviewDoorMode] = useState<boolean>(false);
  const [activeSectionId, setActiveSectionId] = useState<string>('hero');
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  const themePreset = THEME_PRESETS[state.theme] || THEME_PRESETS['royal-regalia'];
  const occasionPreset = OCCASION_PRESETS[state.occasion] || OCCASION_PRESETS['wedding'];

  // Match platform theme object
  const platformTheme: Theme = useMemo(() => {
    return (
      DEFAULT_THEMES.find((t) => t.slug === state.theme) ||
      (DEFAULT_THEMES[0] as Theme)
    );
  }, [state.theme]);

  // Construct the live Experience object from current studio state
  const liveExperience = useMemo(() => {
    return buildLiveExperience(state);
  }, [state]);

  const hostTitle = state.protagonist2
    ? `${state.protagonist1 || 'Aarav'} & ${state.protagonist2 || 'Meera'}`
    : state.protagonist1 || 'Celebration Host';

  // Frame width constraints per viewport mode
  const viewportStyles: Record<ViewportMode, { width: string; resolution: string }> = {
    desktop: { width: '100%', resolution: 'Desktop 1280px' },
    tablet: { width: '768px', resolution: 'Tablet 768 × 1024' },
    mobile: { width: '420px', resolution: 'Mobile 420 × 896' },
  };

  // Section anchors configuration for quick navigation
  const sectionAnchors = [
    { id: 'hero', label: 'Hero', icon: Sparkles, area: 'occasion' as WorkflowArea },
    { id: 'story', label: 'Story', icon: Feather, area: 'story' as WorkflowArea },
    { id: 'couple', label: 'People', icon: Users, area: 'people' as WorkflowArea },
    { id: 'itinerary', label: 'Itinerary', icon: Calendar, area: 'event' as WorkflowArea },
    { id: 'venue', label: 'Venue', icon: MapPin, area: 'event' as WorkflowArea },
    { id: 'rsvp', label: 'RSVP', icon: HeartHandshake, area: 'guests' as WorkflowArea },
    { id: 'shagun', label: 'Shagun', icon: Gift, area: 'guests' as WorkflowArea },
    { id: 'wishes', label: 'Blessings', icon: PenTool, area: 'content' as WorkflowArea },
  ];

  // Scroll to section helper
  const scrollToSection = (sectionId: string, correspondingArea?: WorkflowArea) => {
    setActiveSectionId(sectionId);
    if (correspondingArea && onSelectArea) {
      onSelectArea(correspondingArea);
    }

    if (!scrollContainerRef.current) return;

    if (sectionId === 'hero') {
      scrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    // Try finding by id or data-section inside the canvas container
    const container = scrollContainerRef.current;
    const targetEl =
      container.querySelector(`#sec-${sectionId}`) ||
      container.querySelector(`[data-section="${sectionId}"]`) ||
      container.querySelector(`[id*="${sectionId}"]`);

    if (targetEl) {
      targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      // Approximate fallback positions
      const approximatePositions: Record<string, number> = {
        hero: 0,
        story: 620,
        couple: 1100,
        itinerary: 1650,
        venue: 2200,
        rsvp: 2750,
        shagun: 3200,
        wishes: 3600,
      };
      container.scrollTo({ top: approximatePositions[sectionId] || 0, behavior: 'smooth' });
    }
  };

  // Smoothly scroll when activeArea from left rail changes
  useEffect(() => {
    if (!activeArea) return;
    const areaToSectionMap: Record<WorkflowArea, string> = {
      overview: 'hero',
      occasion: 'hero',
      style: 'hero',
      people: 'couple',
      event: 'itinerary',
      story: 'story',
      content: 'itinerary',
      guests: 'rsvp',
    };
    const targetSection = areaToSectionMap[activeArea];
    if (targetSection) {
      scrollToSection(targetSection);
    }
  }, [activeArea]);

  // Smoothly scroll when explicit jumpTrigger fires
  useEffect(() => {
    if (!jumpTrigger) return;
    const area = jumpTrigger.split('-')[0] as WorkflowArea;
    const areaToSectionMap: Record<WorkflowArea, string> = {
      overview: 'hero',
      occasion: 'hero',
      style: 'hero',
      people: 'couple',
      event: 'itinerary',
      story: 'story',
      content: 'itinerary',
      guests: 'rsvp',
    };
    const targetSection = areaToSectionMap[area];
    if (targetSection) {
      scrollToSection(targetSection);
    }
  }, [jumpTrigger]);

  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        background: '#070709',
        overflow: 'hidden',
        position: 'relative',
      }}
    >
      {/* ─── CANVAS META & CONTROL BAR ─── */}
      <div
        style={{
          width: '100%',
          padding: '10px 24px',
          borderBottom: '1px solid rgba(255, 255, 255, 0.06)',
          background: 'rgba(11, 11, 14, 0.95)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexShrink: 0,
          zIndex: 10,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 12 }}>
          <span
            style={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              backgroundColor: '#10b981',
              boxShadow: '0 0 8px #10b981',
            }}
          />
          <span style={{ fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', color: '#f4f4f5' }}>
            Live Celebration Canvas
          </span>
          <span style={{ color: '#52525b' }}>•</span>
          <span style={{ color: themePreset.accentColor, fontWeight: 600 }}>{themePreset.name}</span>
          <span style={{ color: '#52525b' }}>•</span>
          <span style={{ color: '#a1a1aa', fontFamily: 'monospace', fontSize: 11 }}>
            {viewportStyles[viewport].resolution}
          </span>
        </div>

        {/* Right Canvas Actions: Door entrance test & Full Immersion Guest View */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {/* Mode switcher: Direct Experience Walkthrough vs Test Door Entrance */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, background: '#18181b', padding: 3, borderRadius: 8 }}>
            <button
              type="button"
              onClick={() => setPreviewDoorMode(false)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 5,
                padding: '4px 12px',
                borderRadius: 6,
                fontSize: 11,
                fontWeight: !previewDoorMode ? 700 : 500,
                background: !previewDoorMode ? '#27272a' : 'transparent',
                color: !previewDoorMode ? '#ffffff' : '#a1a1aa',
                border: 'none',
                cursor: 'pointer',
                transition: 'all 0.15s',
              }}
            >
              <Eye size={13} />
              <span>Full Experience</span>
            </button>
            <button
              type="button"
              onClick={() => setPreviewDoorMode(true)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 5,
                padding: '4px 12px',
                borderRadius: 6,
                fontSize: 11,
                fontWeight: previewDoorMode ? 700 : 500,
                background: previewDoorMode ? '#27272a' : 'transparent',
                color: previewDoorMode ? '#fbbf24' : '#a1a1aa',
                border: 'none',
                cursor: 'pointer',
                transition: 'all 0.15s',
              }}
            >
              <Key size={13} />
              <span>Test Door Reveal</span>
            </button>
          </div>

          {/* Full Immersion Guest View Button */}
          {onOpenFullPreview && (
            <button
              type="button"
              onClick={onOpenFullPreview}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '5px 14px',
                borderRadius: 8,
                background: 'rgba(255, 255, 255, 0.08)',
                border: '1px solid rgba(255, 255, 255, 0.16)',
                color: '#f4f4f5',
                fontSize: 11,
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.15s',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.16)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.08)';
              }}
              title="Open full immersion guest preview modal"
            >
              <Maximize2 size={12} />
              <span>Full Preview</span>
            </button>
          )}
        </div>
      </div>

      {/* ─── PREVIEW STAGE CONTAINER ─── */}
      <div
        ref={scrollContainerRef}
        style={{
          flex: 1,
          width: '100%',
          overflowY: 'auto',
          display: 'flex',
          justifyContent: 'center',
          padding: viewport === 'desktop' ? '0' : '20px',
          boxSizing: 'border-box',
          background: 'radial-gradient(circle at 50% 20%, rgba(212, 175, 55, 0.04) 0%, #070709 70%)',
          scrollBehavior: 'smooth',
        }}
      >
        <div
          style={{
            width: viewportStyles[viewport].width,
            maxWidth: viewport === 'desktop' ? '100%' : viewportStyles[viewport].width,
            minHeight: '100%',
            borderRadius: viewport === 'desktop' ? '0' : '20px',
            border: viewport === 'desktop' ? 'none' : '1px solid rgba(255, 255, 255, 0.14)',
            boxShadow: viewport === 'desktop' ? 'none' : '0 25px 70px -15px rgba(0, 0, 0, 0.95)',
            overflow: 'visible',
            position: 'relative',
            backgroundColor: '#07090E',
            transition: 'width 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          {/* Welcome Door Mode Overlay */}
          {previewDoorMode ? (
            <div style={{ position: 'relative', minHeight: '800px', width: '100%', overflow: 'hidden' }}>
              <div
                style={{
                  position: 'absolute',
                  top: 14,
                  right: 14,
                  zIndex: 100,
                  display: 'flex',
                  gap: 8,
                }}
              >
                <button
                  type="button"
                  onClick={() => setPreviewDoorMode(false)}
                  style={{
                    padding: '6px 14px',
                    borderRadius: 8,
                    background: 'rgba(0,0,0,0.7)',
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255,255,255,0.2)',
                    color: '#ffffff',
                    fontSize: 12,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                  }}
                >
                  <RotateCcw size={13} />
                  <span>Exit Door Test</span>
                </button>
              </div>

              <WelcomeDoorDispatcher
                templateSlug={state.theme}
                themeSlug={state.theme}
                title={hostTitle}
                subtitle={state.tagline || 'A Sacred Gathering of Hearts'}
                date={state.date || 'Saturday, February 18, 2027'}
                venue={`${state.venueName || 'Umaid Bhawan Palace'}, ${state.city || 'Jodhpur'}`}
                primaryColor={themePreset.accentColor}
                onFinish={() => setPreviewDoorMode(false)}
              />
            </div>
          ) : (
            /* Direct Real Celebration Universe Rendering */
            <div>
              {state.theme === 'royal-regalia' ? (
                <RoyalRegaliaExperience
                  experience={liveExperience}
                  theme={platformTheme}
                />
              ) : state.theme === 'celestial-parallax' ? (
                <CelestialParallaxExperience
                  experience={liveExperience}
                  theme={platformTheme}
                />
              ) : state.theme === 'minimal-editorial' ? (
                <MinimalEditorialExperience
                  experience={liveExperience}
                  theme={platformTheme}
                />
              ) : state.theme === 'enchanted-glasshouse' ? (
                <EnchantedGlasshouseExperience
                  experience={liveExperience}
                  theme={platformTheme}
                />
              ) : state.theme === 'amalfi-riviera' ? (
                <AmalfiRivieraExperience
                  experience={liveExperience}
                  theme={platformTheme}
                />
              ) : state.theme === 'party-nocturne' ? (
                <PartyNocturneExperience
                  experience={liveExperience}
                  theme={platformTheme}
                />
              ) : state.theme === 'romantic-doors' ? (
                <RomanticDoorsExperience
                  experience={liveExperience}
                  theme={platformTheme}
                />
              ) : state.theme === 'surreal-organimo' ? (
                <SurrealOrganimoExperience
                  experience={liveExperience}
                  theme={platformTheme}
                />
              ) : (
                <RoyalRegaliaExperience
                  experience={liveExperience}
                  theme={platformTheme}
                />
              )}
            </div>
          )}
        </div>
      </div>

      {/* ─── FLOATING IN-CANVAS SECTION QUICK-NAVIGATOR ─── */}
      {!previewDoorMode && (
        <div
          style={{
            position: 'absolute',
            bottom: 20,
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 30,
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            background: 'rgba(11, 11, 15, 0.88)',
            backdropFilter: 'blur(16px)',
            WebkitBackdropFilter: 'blur(16px)',
            border: '1px solid rgba(255, 255, 255, 0.12)',
            borderRadius: 9999,
            padding: '5px 8px',
            boxShadow: '0 12px 32px rgba(0, 0, 0, 0.6), 0 0 15px rgba(212, 175, 55, 0.15)',
          }}
        >
          {sectionAnchors.map((item) => {
            const Icon = item.icon;
            const isCurrent = activeSectionId === item.id;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => scrollToSection(item.id, item.area)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 5,
                  padding: '5px 11px',
                  borderRadius: 9999,
                  fontSize: 11,
                  fontWeight: isCurrent ? 700 : 500,
                  background: isCurrent ? 'rgba(251, 191, 36, 0.18)' : 'transparent',
                  color: isCurrent ? '#fbbf24' : '#a1a1aa',
                  border: isCurrent ? '1px solid rgba(251, 191, 36, 0.35)' : '1px solid transparent',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  whiteSpace: 'nowrap',
                }}
                title={`Jump to ${item.label} section`}
              >
                <Icon size={12} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
